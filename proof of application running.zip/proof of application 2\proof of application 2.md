﻿Pi

with Zend OPcache v7.4.3-4ubuntu2.22, Copyright (c), by Zend Technologies

Configuration apache2handler

Apache Version Apache/2.4.41 (Ubuntu)

Apache API Version 20120211

Server Administrator webmaster@localhost

Hostname:Port 127.0.2.1:80

User/Group www-data(33)/33

Max Requests Per Child: 0 - Keep Alive: on - Max Per Connection: 100

Timeouts Connection: 300 - Keep-Alive: 5

Virtual Server Yes

Server Root /etc/apache2

Loaded Modules core mod\_so mod\_watchdog http\_core mod\_log\_config mod\_logio mod\_version mod\_unixd mod\_access\_compat

mod\_alias mod\_auth\_basic mod\_authn\_core mod\_authn\_file mod\_authz\_core mod\_authz\_host mod\_authz\_user mod\_autoindex mod\_deflate mod\_dir mod\_env mod\_filter mod\_mime prefork mod\_negotiation mod\_php7 mod\_reqtimeout mod\_setenvif mod\_status

Directive Local Value Master Value

engine 1 1 last\_modified 0 0 xbithack 0 0
