﻿PHP Version 7.4.3-4ubuntu2.22

System Linux Master 5.4.0-176-generic #196-Ubuntu SMP Fri Mar 22 16:46:39 UTC 2024 x86\_64

Build Date May 1 2024 10:11:33

Server API Apache 2.0 Handler

Virtual Directory Support disabled

Configuration File (php.ini) Path /etc/php/7.4/apache2

Loaded Configuration File /etc/php/7.4/apache2/php.ini

Scan this dir for additional .ini files /etc/php/7.4/apache2/conf.d

Additional .ini files parsed /etc/php/7.4/apache2/conf.d/10-mysqind.ini,/etc/php/7.4/apache2/conf.d/10-opcache.ini,

/etc/php/7.4/apache2/conf.d/10-pdo.ini,/etc/php/7.4/apache2/conf.d/20-calendar.ini, /etc/php/7.4/apache2/conf.d/20-ctype.ini,/etc/php/7.4/apache2/conf.d/20-exif.ini,/etc/php/7.4/apache2/conf.d/20- ffi.ini,/etc/php/7.4/apache2/conf.d/20-fileinfo.ini,/etc/php/7.4/apache2/conf.d/20-ftp.ini, /etc/php/7.4/apache2/conf.d/20-gettext.ini,/etc/php/7.4/apache2/conf.d/20-iconv.ini, /etc/php/7.4/apache2/conf.d/20-json.ini,/etc/php/7.4/apache2/conf.d/20-mysaii.ini,/etc/php/7.4/apache2/conf.d/20-

pdo\_mysqL.ini,/etc/php/7.4/apache2/conf.d/20-phar.ini,/etc/php/7.4/apache2/conf.d/20-posix.ini, fetc/php/7.4/apache2/conf.d/20-readline.ini,/etc/php/7.4/apache2/conf.d/20-shmop.ini,

/etc/php/7.4/apache2/conf.d/20-sockets.ini,/etc/php/7.4/apache2/conf.d/20-sysvmsg.ini, /etc/php/7.4/apache2/conf.d/20-sysvsem.ini,/etc/php/7.4/apache2/conf.d/20-sysvshm.ini, /etc/php/7.4/apache2/conf.d/20-tokenizer.ini

PHP API 20190902

PHP Extension 20190902

Zend Extension 320190902

Zend Extension Build API320190902,NTS
