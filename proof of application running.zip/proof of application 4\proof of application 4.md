﻿PHP Documentation

.... weyy, ...... Vidiia, Mudaiii .... wey

Editor Peter Cowburn

User Note Maintainers Daniel P. Brown, Thiago Henrique Pojda

Other Contributors Previously active authors, editors and other contributors are listed in the manual.

PHP Quality Assurance Team

lliaAlshanetsky, Joerg Behrens, Antony Dovgal, Stefan Esser, Moriyoshi Koizumi, Magnus Maatta,Sebastian Nohn, Derick Rethans, Melvyn Sopacua, Pierre- Alain Joye, Dmitry Stogov, Felipe Pena, David Soria Parra, Stanislav Malyshev, Julien Pauli, Stephen Zarkos, Anatol Belski, Remi Collet, Ferenc Kovacs

Websites and Infrastructure team

PHP Websites Team Rasmus Lerdorf, Hannes Magnusson, Philip Olson, Lukas Kahwe Smith, Pierre-Alain Joye, Kalle Sommer Nielsen,

Peter Cowburn, Adam Harvey, Ferenc Kovacs, Levi Morrison

Event Maintainers Damien Seguy, Daniel P. Brown Network Infrastructure Daniel P. Brown

Windows Infrastructure Alex Schoenmaker

PHP License

This program is free software; you can redistribute itand/or modify it under the terms of the PHP License as published by the PHP Group and included in the distribution in the file: LICENSE

This program is distributed in the hope that itwill be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FORA PARTICULAR PURPOSE.

If you did not receive a copy of the PHP license, or have any questions about PHP licensing, please contact license@php.net.
