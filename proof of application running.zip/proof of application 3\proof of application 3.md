﻿HTTP Headers Information

HTTP Request Headers

HTTP Request GET /info.php HTTP/1.1 Host 192.168.56.5

Connection keep-alive

Upgrade-Insecure-Requests 1

User-Agent Mozilla/5.0 (X11; Linux x86\_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36

Accept texv/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,\*/\*;q=0.8 application/sign

ed-exchange;v=b3;q=0.7

Accept-Encoding gzip, deflate Accept-Language en-US,en;q=0.9,ar;q=0.8

HTTP Response Headers

calendar

Calendar support enabled

Core

PHP Version 7.4.3-4ubuntu2.22

Directive Local Value Master Value allow\_url\_fopen On On
