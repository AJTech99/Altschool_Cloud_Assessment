﻿BimmeP eh |: 22 +4|eop5 = mal a eee ce

K) vagrant@Master:~ Ix) File Actions Edit View Help

root@Master:/home/vagrant/deployment# ./lLamp\_deploy.sh

Hit:1 http://archive.ubuntu.com/ubuntu focal InRelease

Hit:2 http://security.ubuntu.com/ubuntu focal-security InRelease

Hit:3 http://archive.ubuntu.com/ubuntu focal-updates InRelease

Hit:4 http://archive.ubuntu.com/ubuntu focal-backports InRelease

Reading package Lists... Done

Reading package Lists... Done

Building dependency tree

Reading state information... Done

Calculating upgrade... Done

The following packages have been kept back:

Linux-headers-generic Linux-headers-virtual Linux-image-virtual Linux-virtual

- upgraded, @newly installed, @to remove and 4 not upgraded.

Reading package Lists... Done

Building dependency tree

Reading state information... Done

git is already the newest version (1:2.25.1-1ubuntu3.11).

git set to manually installed.

The following additional packages will be installed:

apache2-bin apache2-data apache2-utils Libapache2-mod-php7.4 Libapri Libaprutil1 Libaprutili1-dbd-sglite3 Libaprutili-ldap Libcgi-fast-perl lLibcgi-pm-perl Libencode-locale-perl Libevent-core-2.1-7 Libevent-pthreads-2.1-7 Libfcgi-perl Libhtml-parser-perl Libhtml-tagset-perl Libhtml-template-perl Libhttp-date-perl Libhttp-message-perl Libio-html-perl Libjansson4 1liblua5.2-0 Liblwp-mediatypes-perl Libmecab2 Libtimedate-perl Liburi-perl mecab-ipadic mecab-ipadic-utf8 mecab-utils mysql-client-8.@ mysql-client-core-8.0 mysql-common mysql-server-8.® mysql-server-core-8.@ php-common php7.4 php7.4-cli php7.4-common php7.4-json php7.4-mysql php7.4-opcache php7.4-readline ssl-cert

Suggested packages:

apache2-doc apache2-suexec-pristine | apache2-suexec-custom ww-browser php-pear Libdata-dump-perl Libipc-sharedcache-perl Libww-perl mailx tinyca openssl-blackList

The following NEWpackages will be installed:

apache2 apache2-bin apache2-data apache2-utils Libapache2-mod-php7.4 Libapri Libaprutil1 Libaprutili-dbd-sglite3 Libaprutili-ldap lLibcgi-fast-perl Libcgi-pm-perl Libencode-locale-perl Libevent-core-2.1-7 Libevent-pthreads-2.1-7 Libfcgi-perl Libhtml-parser-perl Libhtml-tagset-perl Libhtml-template-perl Libhttp-date-perl Libhttp-message-perl Libio-html-perl Libjansson4 liblua5.2-0 Liblwp-mediatypes-perl Libmecab2 Libtimedate-perl Liburi-perl mecab-ipadic mecab-ipadic-utf8 mecab-utils mysql-client-8.@ mysql-client-core-8.0 mysql-common mysql-server mysql-server-8.@ mysql-server-core-8.0 php php-common php-mysql php7.4 php7.4-cli php7.4-common php7.4-json php7.4-mysql php7.4-opcache php7.4-readline ssl-cert

- upgraded, 47 newly installed, ® to remove and 4 not upgraded.

Need to get 42.8 MB of archives.

After this operation, 344 MB of additional disk space will be used.

Get:1 http://archive.ubuntu.com/ubuntu focal/main amd64 Libapri1 amd64 1.6.5-1ubuntu1 [91.4 kB]

Get:2 http://archive.ubuntu.com/ubuntu focal-updates/main amd64 Libaprutil1 amd64 1.6.1-4ubuntu2.2 [85.1 kB]

Get:3 http://archive.ubuntu.com/ubuntu focal-updates/main amd64 Libaprutili-dbd-sqlite3 amd64 1.6.1-4ubuntu2.2 [10.5 kB]

Get:4 http://archive.ubuntu.com/ubuntu focal-updates/main amd64 Libaprutili-ldap amd64 1.6.1-4ubuntu2.2 [8752 B]

Get:5 http://archive.ubuntu.com/ubuntu focal/main amd64 Libjansson4 amd64 2.12-1build1 [28.9 kB]
