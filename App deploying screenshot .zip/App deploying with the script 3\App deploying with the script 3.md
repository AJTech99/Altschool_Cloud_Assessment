﻿eee =e sadeLasnercast v 3®@... |a ©

. vagrant@Master:~ x) File Actions Edit View Help

Setting up mysql-client-core-8.@ (8.0.36-QOubuntu®@.20.04.1) ... Setting up php7.4-common (7.4.3-4ubuntu2.22) ...

Creating config file /etc/php/7.4/mods-available/calendar.ini with newversion

Creating config file /etc/php/7.4/mods-available/ctype.ini with newversion . Screenshot taken Creating config file /etc/php/7.4/mods-available/exif.ini with newversion Viewimage Creating config file /etc/php/7.4/mods-available/fileinfo.ini with newversion

Creating config file /etc/php/7.4/mods-available/ffi.ini with newversion

Creating config file /etc/php/7.4/mods-available/ftp.ini with newversion

Creating config file /etc/php/7.4/mods-available/gettext.ini with newversion

Creating config file /etc/php/7.4/mods-available/iconv.ini with newversion

Creating config file /etc/php/7.4/mods-available/pdo.ini with newversion

Creating config file /etc/php/7.4/mods-available/phar.ini with newversion

Creating config file /etc/php/7.4/mods-available/posix.ini with newversion

Creating config file /etc/php/7.4/mods-available/shmop.ini with newversion

Creating config file /etc/php/7.4/mods-available/sockets.ini with newversion

Creating config file /etc/php/7.4/mods-available/sysvmsg.ini with newversion

Creating config file /etc/php/7.4/mods-available/sysvsem.ini with newversion

Creating config file /etc/php/7.4/mods-available/sysvshm.ini with newversion

Creating config file /etc/php/7.4/mods-available/tokenizer.ini with new version

Setting up php7.4-mysql (7.4.3-4ubuntu2.22) ...

Creating config file /etc/php/7.4/mods-available/mysqlnd.ini with newversion Creating config file /etc/php/7.4/mods-available/mysqli.ini with newversion
