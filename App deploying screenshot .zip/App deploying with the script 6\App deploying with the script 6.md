﻿BimmePO-|:23+|eop50 & Lo YF . . 2] a ©

K) vagrant@Master:~ Ix) File Actions Edit View Help

Processing triggers for man-db (2.9.1-1) ...

Processing triggers for Libc-bin (2.31-Qubuntu9.15) ...

Processing triggers for php7.4-cli (7.4.3-4ubuntu2.22) ...

Processing triggers for Libapache2-mod-php7.4 (7.4.3-4ubuntu2.22) ...

Reading package Lists... Done

Building dependency tree

Reading state information... Done

php is already the newest version (2:7.4+75).

php-mysql is already the newest version (2:7.4+75).

apache2 is already the newest version (2.4.41-4ubuntu3.17).

mysql-server is already the newest version (8.0.36-Qubuntu@.20.04.1).

The following NEWpackages will be installed:

Libapache2-mod-php

® upgraded, 1 newly installed, ® to remove and 4 not upgraded. Need to get 2836 B of archives.

After this operation, 17.4 kB of additional disk space will be used.

Get:1 http://archive.ubuntu.com/ubuntu focal/main amd64 Libapache2-mod-php all 2:7.4+75 [2836 B] Fetched 2836 B in 1s (3073 B/s)

Selecting previously unselected package Libapache2-mod-php.

(Reading database ... 65225 files and directories currently installed.)

Preparing to unpack ... /Libapache2-mod-php\_2%3a7.4+75\_all.deb ...

Unpacking Libapache2-mod-php (2:7.4+75) ...

Setting up Libapache2-mod-php (2:7.4+75) ...

Rules updated

Rules updated (v6)

mysql: [Warning] Using a password on the commandline interface can be insecure.

Cloning into '/var/waw/html/aj-app’...

remote: Enumerating objects: 34470, done.

remote: Counting objects: 100% (26/26), done.

remote: Compressing objects: 100% (19/19), done.

remote: Total 34470 (delta 11), reused 15 (delta 7), pack-reused 34444

Receiving objects: 100% (34470/34470), 10.52 MiB | 709.00 KiB/s, done.

Resolving deltas: 100% (20320/20320), done.

Synchronizing state of apache2.service with SysV service script with /lLib/systemd/systemd-sysv-install. Executing: /Lib/systemd/systemd-sysv-install enable apache2

LAMPstack deployed successfully!

You can access your PHP application at http://YOUR\_SERVER\_IP/info.php root@Master:/home/vagrant/deployment# nano Lamp\_deploy.sh

root@Master:/home/vagrant/deployment# sudo su

root@Master:/home/vagrant/deployment# sudo su Master

su: user Master does not exist
