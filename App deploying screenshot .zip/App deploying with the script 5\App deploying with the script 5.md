﻿LT TE . Jae ee 7 .. @ ... |a@ .

... fn he he

K) vagrant@Master:~ Ix) File Actions Edit View Help

Renaming removed key\_buffer and myisam-recover options (if present)

mysqld will log errors to /var/log/mysql/error.log

mysqld is running as pid 25324

Created symlink /etc/systemd/system/muLti-user.target.wants/mysql.service > /Lib/systemd/system/mysql.service.

Setting up Libcgi-pm-perl (4.46-1) ...

Setting up apache2-bin (2.4.41-4ubuntu3.17) ...

Setting up Libhtml-template-perl (2.97-1) ...

Setting up mysql-server (8.0.36-QOubuntu@.20.04.1) ...

Setting up Libapache2-mod-php7.4 (7.4.3-4ubuntu2.22) ...

Package apache2 is not configured yet. Will defer actions by package Libapache2-mod-php7.4.

Creating config file /etc/php/7.4/apache2/php.ini with new version No module matches

Setting up Libcgi-fast-perl (1:2.15-1) ...

Setting up apache2 (2.4.41-4ubuntu3.17) ...

Enabling module mpm\_event.

Enabling module authz\_core.

Enabling module authz\_host.

Enabling module authn\_core.

Enabling module auth\_basic.

Enabling module access\_compat.

Enabling module authn\_file.

Enabling module authz\_user.

Enabling module alias.

Enabling module dir.

Enabling module autoindex.

Enabling module env.

Enabling module mime.

Enabling module negotiation.

Enabling module setenvif.

Enabling module filter.

Enabling module deflate.

Enabling module status.

Enabling module reqtimeout.

Enabling conf charset.

Enabling conf localized-error-pages.

Enabling conf other-vhosts-access-log.

Enabling conf security.

Enabling conf serve-cgi-bin.

Enabling site 000-default.

info: Switch to mpmprefork for package Libapache2-mod-php7.4
