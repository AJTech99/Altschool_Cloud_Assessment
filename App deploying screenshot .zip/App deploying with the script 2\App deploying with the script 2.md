﻿BimmePeh-|: 234/69mp5 = \* ¢ > @ a 14:41 | @ G

pened | . Alu

K) vagrant@Master: ~ x) File Actions Edit View Help Screenshot taken

Get:46 http://archive.ubuntu.com/ubuntu focal/main amd64 php-mysql all 2:7.4+75 [2000 B]

Get:47 http://archive.ubuntu.com/ubuntu focal/main amd64 ssl-cert all 1.0.39 [17.0 kB] View image Fetched 42.8 MB in 38s (1123 kB/s)

Extracting templates from packages: 100%

Preconfiguring packages ...

Selecting previously unselected package Libapri:amd64.

(Reading database ... 63763 files and directories currently installed.)

Preparing to unpack ... /@0-Libapri\_1.6.5-lubuntu1\_amd64.deb ...

Unpacking Libapri:amd64 (1.6.5-1ubuntu1) ...

Selecting previously unselected package Libaprutil1:amd64.

Preparing to unpack ... /@1-Libaprutil1\_1.6.1-4ubuntu2.2\_amd64.deb ...

Unpacking Libaprutil1:amd64 (1.6.1-4ubuntu2.2) ...

Selecting previously unselected package Libaprutili-dbd-sqlite3:amd64.

Preparing to unpack ... /@2-Libaprutil1-dbd-sqlite3\_1.6.1-4ubuntu2.2\_amd64.deb ...

Unpacking Libaprutili-dbd-sqlite3:amd64 (1.6.1-4ubuntu2.2) ...

Selecting previously unselected package Libaprutil1-ldap:amd64.

Preparing to unpack ... /@3-Libaprutili-ldap\_1.6.1-4ubuntu2.2\_amd64.deb ...

Unpacking Libaprutili-lLdap:amd64 (1.6.1-4ubuntu2.2) ...

Selecting previously unselected package Libjansson4:amd64.

Preparing to unpack ... /@4-Libjansson4\_2.12-1build1\_amd64.deb ...

Unpacking Libjansson4:amd64 (2.12-1build1) ...

Selecting previously unselected package Liblua5.2-0:amd64.

Preparing to unpack ... /@5-Liblua5.2-0\_5.2.4-1.1build3\_amd64.deb ...

Unpacking Liblua5.2-@:amd64 (5.2.4-1.1build3) ...

Selecting previously unselected package apache2-bin.

Preparing to unpack ... /@6-apache2-bin\_2.4.41-4ubuntu3.17\_amd64.deb ...

Unpacking apache2-bin (2.4.41-4ubuntu3.17) ...

Selecting previously unselected package apache2-data.

Preparing to unpack ... /@7-apache2-data\_2.4.41-4ubuntu3.17\_all.deb ...

Unpacking apache2-data (2.4.41-4ubuntu3.17) ...

Selecting previously unselected package apache2-utils.

Preparing to unpack ... /@8-apache2-utils\_2.4.41-4ubuntu3.17\_amd64.deb ...

Unpacking apache2-utils (2.4.41-4ubuntu3.17) ...

Selecting previously unselected package apache2.

Preparing to unpack ... /@9-apache2\_2.4.41-4ubuntu3.17\_amd64.deb ...

Unpacking apache2 (2.4.41-4ubuntu3.17) ...

Selecting previously unselected package mysql-common.

Preparing to unpack ... /10-mysql-common\_5.8+1.0.5ubuntu2\_all.deb ...

Unpacking mysql-common (5.8+1.@.5ubuntu2) ...

Selecting previously unselected package mysql-client-core-8.0.

Preparing to unpack ... /11-mysql-client-core-8.0\_8.0.36-QOubuntu@.20.04.1\_amd64.deb ...
